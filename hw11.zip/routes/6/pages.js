const express = require('express');
const router = express.Router();

const url = require('url');

const path = require('path');

router.get('/', function (req, res) {
    const urlParse = url.parse(req.url, true);
    res.sendFile(`index${urlParse.query.page}.html`, { root: path.join(__dirname, '../../view/5') });
})

router.use(function (req, res) {
    res.status(400).send('not found :(');
})



module.exports = router;