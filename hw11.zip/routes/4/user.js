const express = require('express');
const app = express();
const router = express.Router();

const fs = require('fs');

const bodyParser = require('body-parser');
 
let urlencodedParser = bodyParser.urlencoded({ extended: true })


router.get('/', function (req, res) {
    res.send('user page route');
})

router.post('/getUser', urlencodedParser, function (req, res) {
    let allUser = JSON.parse(fs.readFileSync('./public/4/userInfo.txt', {encoding: 'utf-8'}))
        ,userInfo;

    for(let user of allUser){
        if(user.username === req.body.username){
            userInfo = user;
        }
    }

    res.send((!! userInfo) ? userInfo : `username "${req.body.username}" is not exist`);
})


module.exports = router;