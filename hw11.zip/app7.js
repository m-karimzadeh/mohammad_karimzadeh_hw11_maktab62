const express = require('express');
const app = express();
const path = require('path')

const userRoute = require('./routes/7/user');

app.use('/file', express.static('public/7'));

app.use('/user', userRoute);

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'view/7/index.html'));
})

app.use(function(req, res){
    res.status(400).send('not found :(');
})

app.listen(3000)