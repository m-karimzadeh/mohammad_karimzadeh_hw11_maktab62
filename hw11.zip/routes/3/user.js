const express = require('express');
const router = express.Router();


router.get('/', function (req, res){
    res.send('user profile')
})

router.get('/profile', function(req, res) {
    res.send('user profile page')
});

router.get('/log', function(req, res) {
    res.send('user log list')
});

router.get('/update', function(req, res) {
    res.send('user update profile')
});




module.exports = router;




