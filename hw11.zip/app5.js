const express = require('express');
const app = express();

const pagesRout = require('./routes/5/pages');

app.set('base', '/');

app.use('/pages', pagesRout);

app.get('/', function(req, res){
    res.send('first application');
})


app.listen(3000)