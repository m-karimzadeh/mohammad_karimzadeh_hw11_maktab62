const express = require('express');
const app = express();
const router = express.Router();

const fs = require('fs');

const bodyParser = require('body-parser');
 
let urlencodedParser = bodyParser.urlencoded({ extended: true })


router.get('/', function (req, res) {
    res.send('user page route');
})

router.post('/login', urlencodedParser, function (req, res) {
    let allUser = JSON.parse(fs.readFileSync('./public/7/userInfo.txt', {encoding: 'utf-8'}))
        ,userInfo;

    for(let user of allUser){
        if(user.username === req.body.username && user.password === req.body.password){
            userInfo = user;
        }
    }

    if((!! userInfo)){
        res.json({
            status: 100,
            discription: 'ورود موفقیت آمیز'
        })

    }else{
        res.json({
            status: 400,
            discription: 'کاربری با این مشخصات یافت نشد.'
        })
    }
})


module.exports = router;