const express = require('express');
const router = express.Router();

const fs = require('fs');

router.get('/', function (req, res) {
    res.send('admin page route');
})

router.get('/getAllUser', function (req, res) {
    try{
        let allUser = fs.readFileSync('./public/4/userInfo.txt', {encoding: 'utf-8'});
        res.send(allUser);

    }catch(error){
        res.send('list not found :(');
    }
})


module.exports = router;