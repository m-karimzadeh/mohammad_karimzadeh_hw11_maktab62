const express = require('express');
const app = express();
const path = require('path')

const userRoute = require('./routes/4/user');
const adminRoute = require('./routes/4/admin');

app.use('/user', userRoute);
app.use('/admin', adminRoute);

app.get('/', function (req, res) {
    res.sendFile(path.join(__dirname, 'view/4/index.html'));
})


app.listen(3000)