const express = require('express');
const router = express.Router();

const path = require('path');

router.get('/', function(req, res){
    res.send('pages? :(');
})

router.get('/index1', function(req, res){
    res.sendFile('index1.html', { root: path.join(__dirname, '../../view/5') });
})

router.get('/index2', function(req, res){
    res.sendFile('index2.html', { root: path.join(__dirname, '../../view/5') });
})

router.get('/index3', function(req, res){
    res.sendFile('index3.html', { root: path.join(__dirname, '../../view/5') });
})

router.get('/index4', function(req, res){
    res.sendFile('index4.html', { root: path.join(__dirname, '../../view/5') });
})

router.get('/index5', function(req, res){
    res.sendFile('index5.html', { root: path.join(__dirname, '../../view/5') });
})




module.exports = router;