const express = require('express');
const app = express();

const pagesRout = require('./routes/6/pages');

app.set('base', '/');

app.use('/pages', pagesRout);

app.get('/', function (req, res) {
    res.send('first application');
})

app.use(function (req, res) {
    res.status(400).send('not found :(');
})


app.listen(3000)