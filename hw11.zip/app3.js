const express = require('express');
const app = express();

const User = require('./routes/3/user')

app.get('/', function (req, res){
    res.send('hellow world')
})

app.use('/user', User)


app.listen(3000);