const express = require('express');
const app = express();

app.use('/file', express.static('public'));

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/view/2/index.html');
})



app.listen(3000);